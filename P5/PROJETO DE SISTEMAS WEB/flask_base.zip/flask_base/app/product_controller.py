# app/product_controller.py
from flask import Blueprint, jsonify, request
from .models import Product, db

product_bp = Blueprint('product_bp', __name__)

@product_bp.route('/', methods=['GET'])
def get_products():
    products = Product.query.all()
    return jsonify([{"id": product.id, "name": product.name} for product in products])

@product_bp.route('/', methods=['POST'])
def add_product():
    data = request.get_json()
    new_product = Product(name=data['name'])
    db.session.add(new_product)
    db.session.commit()
    return jsonify({"message": "Product added successfully!"}), 201
